# pixx
Zero-overhead Sans-I/O terminal render engine -- Kitty Graphics Protocol

Architecture:
  SIMD memchr3 -> L0 wymix VRAM -> L1 64-slot ring -> L2 BLAKE3+LZ4 CAS -> KGP U+10EEEE

Supported file formats:
  .md .qmd .rmd .mdx .ipynb .tex .latex .typ
  .mmd .mermaid .dot .gv .svg .svgz .csv .tsv
  .png .vl .vegalite .plotly .ttf .otf .ttc
  .zip .tar .tgz .tbz2 .txz .tzst .7z .rar
  .iso .dmg .pkg .deb .rpm .whl .jar
