//! Criterion suite: scan_throughput, pipeline_warm, cache, frontends_zero_alloc.
//! benches/daemon.rs: fork/exec vs zero-fork UDS tail-latency comparison.
