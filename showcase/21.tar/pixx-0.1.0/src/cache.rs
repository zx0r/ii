//! Three-tier cache hierarchy:
//!   L0: 64-bit wymix non-cryptographic VRAM tagger  (compute_vram_tag)
//!   L1: thread-local 64-way ring buffer              (L1_CACHE)
//!   L2: BLAKE3-keyed, LZ4-compressed disk CAS       (PX01 magic, .px1 files)
//!       openat on cached dir fd + atomic renameat writes
