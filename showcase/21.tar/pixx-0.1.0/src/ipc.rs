//! Zero-fork AF_UNIX daemon (IpcServer, run_daemon).
//! IXPC v1 Header: 32 bytes -- 2 headers per 64-byte cacheline.
//!
//! Commands:
//!   PING                  = 0x0001
//!   CMD_COMPOSE_ANSI      = 0x0002
//!   CMD_COMPOSE_EXTMARKS  = 0x0003
//!   CMD_RENDER_FILE       = 0x0004
//!   SHUTDOWN              = 0x0006
//!
//! DevSecOps socket hardening: dir 0700, socket 0600, CWE-59 symlink reject.
