//! Kitty Graphics Protocol: APC/DCS command formatter, RFC 4648 Base64 codec,
//! U+10EEEE Unicode Placeholder grid encoder.
//!
//! FIRST_CELL_8_LUT : 1024-entry static table => 8-byte register copy per cell.
//! PLACEHOLDER_RUN  : 1024-byte SIMD memcpy for implicit column auto-increment.
//!
//! Image ID invariant: non-zero 24-bit ID from BLAKE3 key:
//!   (b[0] << 16 | b[1] << 8 | b[2]).max(1)
