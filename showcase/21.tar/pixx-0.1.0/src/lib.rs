//! Core Pipeline state machine, Scratchpad memory arena, VramEntry L0 residency table.
//! All hot-path structs: Copy + #[repr(C)] + 16 bytes, compile-time size asserts.

#[repr(C)]
pub struct VramEntry {
    pub tag:      u64,  // 64-bit wymix non-cryptographic hash
    pub image_id: u32,  // Non-zero 24-bit KGP image ID
    pub cols:     u16,  // Cell-snapped column count
    pub rows:     u16,  // Cell-snapped row count
}
const _: () = assert!(core::mem::size_of::<VramEntry>() == 16);
