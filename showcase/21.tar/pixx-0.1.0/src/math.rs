//! ratex (ratex-parser / ratex-layout / ratex-svg) TeX-to-SVG compiler.
//! compile_math_svg: deterministic SVG with error badge fallback.
