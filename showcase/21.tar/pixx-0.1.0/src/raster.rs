//! Single-pass zero-allocation SVG color rewriter (rewrite_svg_colors),
//! cell-snapped resvg/tiny-skia vector-to-RGBA rasterizer (rasterize_span),
//! PNG decoder for notebook outputs (decode_png_into).
