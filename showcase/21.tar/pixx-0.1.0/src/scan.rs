//! SIMD memchr3 single-pass lexer: Markdown, LaTeX math ($...$  $$...$$),
//! fenced code blocks (mermaid dot svg csv), ipynb outputs.
//! Span: 16 bytes, 4 spans per 64-byte cacheline. Zero heap alloc in hot path.

#[repr(C)]
pub struct Span {
    pub outer_start:        u32,
    pub outer_end:          u32,
    pub payload_start:      u32,
    pub payload_end_and_kind: u32, // 28-bit offset | 4-bit SpanKind
}
const _: () = assert!(core::mem::size_of::<Span>() == 16);
