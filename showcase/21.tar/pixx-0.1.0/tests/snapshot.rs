//! tests/snapshot.rs : deterministic render regression suite.
//! tests/daemon.rs   : IXPC UDS daemon end-to-end (just e2e).
